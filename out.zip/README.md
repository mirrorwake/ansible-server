This repo is for my personal Ansible setup. Still a work in progress!
