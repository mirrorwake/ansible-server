#!/bin/bash
sudo apt install -y wget curl vi openssl git ansible
git clone [PUT REPO HERE]
cd [REPO]

